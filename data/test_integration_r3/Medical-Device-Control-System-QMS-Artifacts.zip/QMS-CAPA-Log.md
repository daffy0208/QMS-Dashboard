# CAPA Log
## Medical Device Control System

**Risk Level:** R3
**Date:** 2025-12-15
**Status:** Active

---

## Corrective and Preventive Actions

No entries yet.

**Note:** Log corrective and preventive actions as issues arise.
